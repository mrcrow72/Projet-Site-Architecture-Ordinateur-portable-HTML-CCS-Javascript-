# Dans mon portable

Site éducatif sur l'architecture d'un ordinateur portable. Le visiteur assemble huit composants pièce par pièce, répond à un quiz sur chacun, puis monte l'ordinateur complet.

## Ouvrir le site

- Sans rien installer : double-cliquez sur `index.html`.
- Dans VS Code : ouvrez le dossier, puis cliquez sur Go Live (extension Live Server).

## Le mettre en ligne avec GitHub Pages

1. Déposez tout le contenu de ce dossier à la racine de votre dépôt, puis faites Commit et Push.
2. Sur GitHub : Settings, Pages, Source « Deploy from a branch », branche `main`, dossier `/ (root)`, Save.
3. Après quelques minutes, l'adresse du site s'affiche en haut de la page Pages.

## Les fichiers

```
index.html            la seule page du site, avec ses trois vues
css/style.css         toute la mise en forme (les couleurs sont dans :root)
js/donnees.js         tout le contenu : textes, pièces, positions, quiz
js/progression.js     sauvegarde de l'avancement dans le navigateur
js/atelier.js         moteur d'assemblage (glisser, poser, vérifier)
js/accueil.js         vue d'accueil
js/composant.js       vue d'un composant : aperçu, assemblage, quiz
js/ordinateur.js      vue du montage final
js/navigation.js      choisit la vue d'après la fin de l'adresse
images/               un dossier par composant, un fichier SVG par pièce
```

## Comment ça marche

- **Une page, trois vues.** La fin de l'adresse choisit la vue : `index.html` affiche l'accueil, `index.html#ram` le composant dont l'identifiant est `ram`, `index.html#ordinateur` le montage final. C'est le rôle de `navigation.js`.
- **Les données pilotent tout.** `COMPOSANTS` décrit les huit composants. `ORDINATEUR` a la même forme : ses pièces sont les composants entiers.
- **Un seul moteur.** `creerAtelier(zone, objet, quandTermine)` sert pour chaque composant et pour le montage final. Avec `ordre: true`, les pièces doivent être posées dans l'ordre de la liste.
- **Les positions.** Chaque pièce a `x`, `y`, `l`, `h`, lus sur un plan de 400 sur 300. Le `viewBox` de son image vaut `0 0 l h`. L'ordre des pièces dans la liste est leur ordre d'empilement.
- **La progression.** Elle est gardée dans le `localStorage` du navigateur, sous la clé `portable-progression`.

## Modifier ou ajouter un composant

1. Dans `js/donnees.js`, copiez le bloc d'un composant et changez son `id`, ses textes, ses pièces et son quiz.
2. Dessinez une image par pièce dans `images/<id>/`, plus une image `complet.svg` du composant entier.
3. Ajoutez le composant dans `ORDINATEUR.pieces`, à sa place dans l'ordre du montage, avec sa position sur le châssis.

## À personnaliser

- Le nom du site : la balise `<title>` et le logo dans `index.html`, plus `document.title` dans les fichiers `accueil.js`, `composant.js` et `ordinateur.js`.
- Vos prénoms : le pied de page de `index.html`.
- Les couleurs : le bloc `:root` de `css/style.css`.
- Les textes et les quiz : `js/donnees.js`. Vérifiez chaque affirmation avant de publier.

## Ce qui a été vérifié

Le parcours complet a été joué dans Chrome : les huit composants à la souris, un composant au clavier (Tab, puis Entrée), les quiz, la sauvegarde après rechargement, l'ordre imposé du montage final et l'affichage sur un écran de 1366 pixels et sur une largeur de téléphone.

Le glisser au doigt n'a pas été simulé. Testez-le sur un vrai téléphone une fois le site en ligne.

Les deux polices viennent de Google Fonts. Sans connexion, le site utilise les polices du système.

## Différences avec le cours

Le cours décrit une variante à trois pages (`index.html`, `composant.html?id=ram`, `ordinateur.html`). Ce site tient en une seule page et lit l'ancre de l'adresse (`#ram`), comme le site modèle. Les notions sont les mêmes : données, boucle qui fabrique l'affichage, moteur d'assemblage, sauvegarde.

Le moteur a aussi trois ajouts : l'ordre imposé pour le montage final, les pièces mélangées dans la réserve et un message à chaque geste.
