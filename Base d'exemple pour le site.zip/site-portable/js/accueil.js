// accueil.js : la vue d'accueil, avec la liste des composants et le bloc du montage final.

function afficherAccueil() {
  document.title = "Dans mon portable";

  // 1. Une carte par composant, fabriquée à partir des données.
  const liste = document.querySelector("#liste-composants");
  liste.innerHTML = "";
  let premierAFaire = null;

  for (let rang = 0; rang < COMPOSANTS.length; rang++) {
    const composant = COMPOSANTS[rang];
    const carte = document.createElement("a");
    carte.className = "carte";
    carte.href = "#" + composant.id;
    carte.innerHTML = `
      <span class="numero">${rang + 1}</span>
      <img class="vignette" src="${composant.image}" alt="">
      <h3>${composant.nom}</h3>
      <p>${composant.resume}</p>
      <span class="etat">À assembler</span>`;

    if (estTermine(composant.id)) {
      carte.classList.add("terminee");
      carte.querySelector(".etat").textContent = "Assemblé";
    } else if (premierAFaire === null) {
      premierAFaire = composant;
    }
    liste.appendChild(carte);
  }

  // 2. Le bouton du haut mène au premier composant qui reste à assembler.
  const boutonCommencer = document.querySelector("#bouton-commencer");
  if (premierAFaire === null) {
    boutonCommencer.href = "#ordinateur";
    boutonCommencer.textContent = "Monter l'ordinateur";
  } else {
    boutonCommencer.href = "#" + premierAFaire.id;
    if (compterTermines() === 0) {
      boutonCommencer.textContent = "Commencer";
    } else {
      boutonCommencer.textContent = "Continuer";
    }
  }

  // 3. Le montage final reste verrouillé tant qu'il manque des composants.
  const restants = COMPOSANTS.length - compterTermines();
  const boutonFinal = document.querySelector("#bouton-final");
  const texteFinal = document.querySelector("#texte-final");

  if (restants > 0) {
    boutonFinal.classList.add("verrouille");
    boutonFinal.setAttribute("aria-disabled", "true");
    texteFinal.textContent = `Encore ${restants} composant(s) à assembler pour débloquer le montage.`;
  } else {
    boutonFinal.classList.remove("verrouille");
    boutonFinal.removeAttribute("aria-disabled");
    if (estTermine(ORDINATEUR.id)) {
      texteFinal.textContent = "Ordinateur déjà monté. Tu peux refaire le montage quand tu veux.";
    } else {
      texteFinal.textContent = "Tous les composants sont prêts. À toi de monter l'ordinateur.";
    }
  }
}

// Le lien du bas efface la progression et réaffiche l'accueil.
document.querySelector("#bouton-recommencer").addEventListener("click", function () {
  effacerProgression();
  afficherVue();
});
