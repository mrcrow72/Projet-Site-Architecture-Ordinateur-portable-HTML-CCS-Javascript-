// atelier.js : le moteur d'assemblage. Il sert pour chaque composant ET pour l'ordinateur complet.

const PLAN_LARGEUR = 400;
const PLAN_HAUTEUR = 300;
const MARGE = 20; // tolérance en pixels autour de l'emplacement

// Construit un atelier dans "zone" pour "objet" (un composant ou l'ordinateur).
// "quandTermine" est une fonction appelée quand toutes les pièces sont posées.
// Si objet.ordre vaut true, les pièces doivent être posées dans l'ordre de la liste.
function creerAtelier(zone, objet, quandTermine) {
  zone.classList.remove("termine");
  zone.innerHTML = `
    <p class="consigne"></p>
    <div class="plateau"></div>
    <div class="reserve"></div>
    <p class="message" aria-live="polite">Attrape une pièce et dépose-la sur son emplacement. Au clavier : Tab, puis Entrée.</p>`;

  const consigne = zone.querySelector(".consigne");
  const plateau = zone.querySelector(".plateau");
  const reserve = zone.querySelector(".reserve");
  const message = zone.querySelector(".message");
  const total = objet.pieces.length;
  let posees = 0;

  // Écrit la consigne du moment, au-dessus du plateau.
  function ecrireConsigne() {
    if (posees === total) {
      consigne.textContent = "Assemblage terminé.";
    } else if (objet.ordre) {
      consigne.textContent = `Étape ${posees + 1} sur ${total} : ${objet.pieces[posees].nom}.`;
    } else {
      consigne.textContent = `Fais glisser chaque pièce à sa place. Pièces posées : ${posees} sur ${total}.`;
    }
  }

  // L'image de fond du plateau, s'il y en a une (le châssis de l'ordinateur).
  if (objet.fond) {
    const fond = document.createElement("img");
    fond.className = "fond";
    fond.src = objet.fond;
    fond.alt = "";
    plateau.appendChild(fond);
  }

  const images = [];

  for (let rang = 0; rang < total; rang++) {
    const piece = objet.pieces[rang];

    // 1. L'emplacement : un cadre en pointillés, placé en pourcentage du plateau.
    const emplacement = document.createElement("div");
    emplacement.className = "emplacement";
    emplacement.dataset.piece = piece.id;
    emplacement.style.left = (piece.x / PLAN_LARGEUR * 100) + "%";
    emplacement.style.top = (piece.y / PLAN_HAUTEUR * 100) + "%";
    emplacement.style.width = (piece.l / PLAN_LARGEUR * 100) + "%";
    emplacement.style.height = (piece.h / PLAN_HAUTEUR * 100) + "%";
    plateau.appendChild(emplacement);

    // 2. La pièce : une image, affichée en petit dans la réserve.
    const image = document.createElement("img");
    const taille = tailleEnReserve(piece);
    image.className = "piece";
    image.src = piece.image;
    image.alt = piece.nom;
    image.title = piece.nom;
    image.draggable = false;
    image.tabIndex = 0;
    image.style.width = taille.largeur + "px";
    image.style.height = taille.hauteur + "px";
    images.push(image);

    // 3. Les réactions de l'atelier à ce qui arrive à cette pièce.
    rendreDeplacable(image, emplacement, {
      quandPrise: function () {
        message.textContent = piece.nom + " : où va cette pièce ?";
      },
      peutPoser: function () {
        return !objet.ordre || rang === posees;
      },
      quandRefusee: function () {
        message.textContent = "Pas encore. Il faut d'abord poser : " + objet.pieces[posees].nom + ".";
      },
      quandRatee: function () {
        message.textContent = piece.nom + " : ce n'est pas là. La pièce retourne dans la réserve.";
      },
      quandPosee: function () {
        posees = posees + 1;
        message.textContent = piece.nom + " : " + piece.info;
        ecrireConsigne();
        if (posees === total) {
          zone.classList.add("termine");
          quandTermine();
        }
      }
    });
  }

  // Les pièces entrent dans la réserve dans un ordre mélangé.
  for (const image of melanger(images)) {
    reserve.appendChild(image);
  }
  ecrireConsigne();
}

// Permet de déplacer "piece" à la souris ou au doigt, et de la poser sur "emplacement".
// "reactions" regroupe les fonctions à appeler selon ce qui se passe.
function rendreDeplacable(piece, emplacement, reactions) {
  let departX = 0;
  let departY = 0;
  let enMain = false;
  let aBouge = false;

  function poser() {
    emplacement.appendChild(piece);
    emplacement.classList.add("rempli");
    piece.classList.add("posee");
    piece.style.width = "";
    piece.style.height = "";
    piece.tabIndex = -1;
    reactions.quandPosee();
  }

  function essayerDePoser() {
    if (reactions.peutPoser()) {
      poser();
    } else {
      reactions.quandRefusee();
    }
  }

  piece.addEventListener("pointerdown", function (evenement) {
    if (piece.classList.contains("posee")) {
      return;
    }
    enMain = true;
    aBouge = false;
    departX = evenement.clientX;
    departY = evenement.clientY;
    piece.setPointerCapture(evenement.pointerId);
    piece.classList.add("en-main");
    reactions.quandPrise();
  });

  piece.addEventListener("pointermove", function (evenement) {
    if (!enMain) {
      return;
    }
    const dx = evenement.clientX - departX;
    const dy = evenement.clientY - departY;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
      aBouge = true;
    }
    piece.style.transform = `translate(${dx}px, ${dy}px)`;
  });

  function lacher() {
    if (!enMain) {
      return;
    }
    enMain = false;
    piece.classList.remove("en-main");
    const surPlace = estSurEmplacement(piece, emplacement);
    piece.style.transform = "";
    if (surPlace) {
      essayerDePoser();
    } else if (aBouge) {
      reactions.quandRatee();
    }
  }

  piece.addEventListener("pointerup", lacher);
  piece.addEventListener("pointercancel", lacher);

  // Au clavier : la touche Entrée pose directement la pièce.
  piece.addEventListener("keydown", function (evenement) {
    if (evenement.key === "Enter" && !piece.classList.contains("posee")) {
      essayerDePoser();
    }
  });
}

// Vrai si le centre de la pièce est dans l'emplacement (avec une petite marge).
function estSurEmplacement(piece, emplacement) {
  const p = piece.getBoundingClientRect();
  const e = emplacement.getBoundingClientRect();
  const centreX = p.left + p.width / 2;
  const centreY = p.top + p.height / 2;
  return centreX > e.left - MARGE && centreX < e.right + MARGE &&
         centreY > e.top - MARGE && centreY < e.bottom + MARGE;
}

// Calcule la taille d'une pièce dans la réserve : son plus grand côté fait entre 80 et 150 pixels.
function tailleEnReserve(piece) {
  const plusGrand = Math.max(piece.l, piece.h);
  let echelle = 0.45;
  if (plusGrand * echelle > 150) {
    echelle = 150 / plusGrand;
  }
  if (plusGrand * echelle < 80) {
    echelle = 80 / plusGrand;
  }
  return {
    largeur: Math.round(piece.l * echelle),
    hauteur: Math.round(piece.h * echelle)
  };
}

// Renvoie une copie de la liste, dans un ordre tiré au hasard.
function melanger(liste) {
  const copie = liste.slice();
  for (let i = copie.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temporaire = copie[i];
    copie[i] = copie[j];
    copie[j] = temporaire;
  }
  return copie;
}
