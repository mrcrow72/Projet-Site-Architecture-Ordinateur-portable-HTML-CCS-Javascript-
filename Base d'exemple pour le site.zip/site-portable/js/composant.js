// composant.js : la vue d'un composant, avec ses trois onglets (Aperçu, Assemblage, Quiz).

let composantAffiche = null;

function afficherComposant(composant) {
  composantAffiche = composant;
  const rang = rangComposant(composant.id);

  document.title = composant.nom + " | Dans mon portable";
  document.querySelector("#numero-lecon").textContent = `Composant ${rang + 1} sur ${COMPOSANTS.length}`;
  document.querySelector("#titre").textContent = composant.nom;
  document.querySelector("#resume").textContent = composant.resume;
  document.querySelector("#role").textContent = composant.role;
  document.querySelector("#analogie").textContent = composant.analogie;

  const image = document.querySelector("#image-composant");
  image.src = composant.image;
  image.alt = composant.nom + ", toutes pièces assemblées";

  // Onglet Aperçu : la liste des pièces, avec leur dessin.
  const listePieces = document.querySelector("#liste-pieces");
  listePieces.innerHTML = "";
  for (const piece of composant.pieces) {
    const ligne = document.createElement("li");
    ligne.innerHTML = `<img src="${piece.image}" alt=""><span><strong>${piece.nom}.</strong> ${piece.info}</span>`;
    listePieces.appendChild(ligne);
  }

  // Onglet Assemblage et onglet Quiz.
  lancerAssemblage(composant);
  afficherQuiz(document.querySelector("#questions"), composant.quiz);

  // Les liens vers le composant précédent et le suivant.
  const precedent = document.querySelector("#lien-precedent");
  const suivant = document.querySelector("#lien-suivant");
  if (rang === 0) {
    precedent.href = "#accueil";
    precedent.textContent = "Retour à l'accueil";
  } else {
    precedent.href = "#" + COMPOSANTS[rang - 1].id;
    precedent.textContent = "Précédent : " + COMPOSANTS[rang - 1].nom;
  }
  if (rang === COMPOSANTS.length - 1) {
    suivant.href = "#ordinateur";
    suivant.textContent = "Suite : monter l'ordinateur";
  } else {
    suivant.href = "#" + COMPOSANTS[rang + 1].id;
    suivant.textContent = "Suivant : " + COMPOSANTS[rang + 1].nom;
  }

  ouvrirOnglet("apercu");
}

// Prépare l'atelier du composant. Quand tout est posé, le composant est marqué comme terminé.
function lancerAssemblage(composant) {
  const bravo = document.querySelector("#bravo");
  bravo.hidden = true;
  creerAtelier(document.querySelector("#atelier"), composant, function () {
    marquerTermine(composant.id);
    mettreAJourEntete();
    bravo.hidden = false;
  });
}

// Fabrique les questions du quiz à partir des données.
function afficherQuiz(zone, questions) {
  zone.innerHTML = "";

  for (let rangQuestion = 0; rangQuestion < questions.length; rangQuestion++) {
    const question = questions[rangQuestion];
    const bloc = document.createElement("div");
    bloc.className = "question";
    bloc.innerHTML = `<p class="enonce">${question.question}</p><p class="explication" hidden>${question.explication}</p>`;
    const explication = bloc.querySelector(".explication");

    for (let numero = 0; numero < question.choix.length; numero++) {
      const bouton = document.createElement("button");
      bouton.className = "choix";
      bouton.type = "button";
      bouton.id = `choix-${rangQuestion + 1}-${numero + 1}`;
      bouton.textContent = question.choix[numero];
      bouton.addEventListener("click", function () {
        if (numero === question.bonne) {
          bouton.classList.add("juste");
          explication.hidden = false;
          // La bonne réponse est trouvée : on fige les boutons de cette question.
          for (const autre of bloc.querySelectorAll(".choix")) {
            autre.disabled = true;
          }
        } else {
          bouton.classList.add("faux");
          bouton.disabled = true;
        }
      });
      bloc.insertBefore(bouton, explication);
    }
    zone.appendChild(bloc);
  }
}

// Montre le panneau demandé ("apercu", "assemblage" ou "quiz") et cache les deux autres.
function ouvrirOnglet(nom) {
  for (const onglet of document.querySelectorAll(".onglet")) {
    if (onglet.dataset.panneau === nom) {
      onglet.classList.add("actif");
    } else {
      onglet.classList.remove("actif");
    }
  }
  for (const panneau of document.querySelectorAll(".panneau")) {
    panneau.hidden = panneau.id !== "panneau-" + nom;
  }
}

// Les boutons de la vue : onglets et raccourcis. Ils sont branchés une seule fois.
for (const onglet of document.querySelectorAll(".onglet")) {
  onglet.addEventListener("click", function () {
    ouvrirOnglet(onglet.dataset.panneau);
  });
}

document.querySelector("#bouton-assembler").addEventListener("click", function () {
  ouvrirOnglet("assemblage");
});

document.querySelector("#bouton-vers-quiz").addEventListener("click", function () {
  ouvrirOnglet("quiz");
});

document.querySelector("#bouton-reassembler").addEventListener("click", function () {
  lancerAssemblage(composantAffiche);
});
