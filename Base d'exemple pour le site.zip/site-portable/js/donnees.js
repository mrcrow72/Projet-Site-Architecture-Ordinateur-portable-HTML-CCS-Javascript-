// donnees.js : tout le contenu du site est ici.
// Pour ajouter un composant, on ajoute un objet dans la liste. On ne touche pas au reste du code.
// Les positions (x, y, l, h) se lisent sur un plan de 400 x 300.
// L'ordre des pièces est l'ordre d'empilement : la première est en dessous.

const COMPOSANTS = [
  {
    id: "carte-mere",
    nom: "Carte mère",
    resume: "Le réseau de routes : elle relie tous les composants.",
    role: "La carte mère porte le processeur et relie entre eux la mémoire, le stockage, l'écran et les ports. Ses pistes de cuivre transportent les données et le courant d'un composant à l'autre.",
    analogie: "C'est la cuisine elle-même, avec ses passages : tout le monde circule grâce à elle.",
    image: "images/carte-mere/complet.svg",
    pieces: [
      { id: "circuit", nom: "Circuit imprimé", info: "Plusieurs couches de pistes de cuivre, collées les unes sur les autres, qui relient tous les composants.", image: "images/carte-mere/circuit.svg", x: 50, y: 40, l: 300, h: 220 },
      { id: "support", nom: "Emplacement du processeur", info: "L'endroit où le processeur est fixé. Dans la plupart des portables, il y est soudé.", image: "images/carte-mere/support.svg", x: 240, y: 60, l: 90, h: 90 },
      { id: "connecteur-ram", nom: "Connecteur de mémoire", info: "Il reçoit la barrette de mémoire vive.", image: "images/carte-mere/connecteur-ram.svg", x: 70, y: 215, l: 180, h: 24 },
      { id: "connecteur-m2", nom: "Connecteur M.2", info: "Il reçoit le SSD, qui s'y glisse à plat.", image: "images/carte-mere/connecteur-m2.svg", x: 70, y: 70, l: 16, h: 56 },
      { id: "ports", nom: "Ports", info: "USB, HDMI, prise casque : les portes de l'ordinateur vers l'extérieur.", image: "images/carte-mere/ports.svg", x: 36, y: 110, l: 30, h: 100 }
    ],
    quiz: [
      {
        question: "Quel est le rôle principal de la carte mère ?",
        choix: ["Stocker les fichiers", "Relier tous les composants entre eux", "Refroidir le processeur"],
        bonne: 1,
        explication: "La carte mère est le support commun : chaque composant s'y branche et communique grâce à elle."
      },
      {
        question: "Par où passent les données sur la carte mère ?",
        choix: ["Par des tuyaux d'air", "Par des ondes radio", "Par des pistes de cuivre"],
        bonne: 2,
        explication: "Les pistes sont de fins chemins de cuivre tracés dans le circuit imprimé."
      }
    ]
  },
  {
    id: "processeur",
    nom: "Processeur",
    resume: "Le cerveau : il exécute les instructions des programmes.",
    role: "Le processeur lit les instructions des programmes et les exécute une par une, des milliards de fois par seconde. Ses cœurs, sa mémoire cache et sa partie graphique sont des zones gravées dans une seule et même puce.",
    analogie: "C'est le chef de la cuisine : il lit les recettes et fait le travail.",
    image: "images/processeur/complet.svg",
    pieces: [
      { id: "substrat", nom: "Substrat", info: "Une petite plaque qui relie la puce à la carte mère par de très nombreux contacts.", image: "images/processeur/substrat.svg", x: 100, y: 50, l: 200, h: 200 },
      { id: "puce", nom: "Puce de silicium", info: "Un rectangle de silicium gravé de milliards de transistors, de minuscules interrupteurs.", image: "images/processeur/puce.svg", x: 130, y: 95, l: 140, h: 110 },
      { id: "coeurs", nom: "Cœurs", info: "Chaque cœur exécute des instructions. Avec plusieurs cœurs, plusieurs tâches avancent en même temps.", image: "images/processeur/coeurs.svg", x: 138, y: 103, l: 80, h: 60 },
      { id: "graphique", nom: "Partie graphique", info: "Cette zone calcule les images envoyées à l'écran.", image: "images/processeur/graphique.svg", x: 224, y: 103, l: 38, h: 60 },
      { id: "cache", nom: "Mémoire cache", info: "Une petite mémoire ultra-rapide pour les données dont le processeur a besoin tout de suite.", image: "images/processeur/cache.svg", x: 138, y: 169, l: 124, h: 28 }
    ],
    quiz: [
      {
        question: "Que fait le processeur ?",
        choix: ["Il exécute les instructions des programmes", "Il stocke les fichiers", "Il affiche l'image"],
        bonne: 0,
        explication: "Stocker est le travail du SSD, afficher celui de l'écran. Le processeur, lui, calcule."
      },
      {
        question: "À quoi servent plusieurs cœurs ?",
        choix: ["À garder les fichiers plus longtemps", "À faire avancer plusieurs tâches en même temps", "À refroidir la puce"],
        bonne: 1,
        explication: "Chaque cœur peut exécuter ses propres instructions pendant que les autres travaillent."
      }
    ]
  },
  {
    id: "refroidissement",
    nom: "Refroidissement",
    resume: "Le climatiseur : il évacue la chaleur du processeur.",
    role: "Un processeur qui travaille chauffe beaucoup. Le système de refroidissement emporte cette chaleur loin de la puce et la souffle hors de l'ordinateur. Sans lui, le processeur ralentirait pour se protéger, puis s'éteindrait.",
    analogie: "C'est la hotte de la cuisine : elle aspire la chaleur et la rejette dehors.",
    image: "images/refroidissement/complet.svg",
    pieces: [
      { id: "plaque", nom: "Plaque de contact", info: "Une plaque de cuivre posée sur le processeur : elle capte sa chaleur.", image: "images/refroidissement/plaque.svg", x: 30, y: 102, l: 90, h: 90 },
      { id: "caloduc", nom: "Caloduc", info: "Un tube de cuivre scellé. À l'intérieur, un liquide s'évapore côté chaud et se condense côté froid : il transporte la chaleur très vite.", image: "images/refroidissement/caloduc.svg", x: 65, y: 90, l: 290, h: 67 },
      { id: "ventilateur", nom: "Ventilateur", info: "Il aspire l'air frais et le pousse à travers les ailettes.", image: "images/refroidissement/ventilateur.svg", x: 200, y: 115, l: 90, h: 90 },
      { id: "radiateur", nom: "Radiateur à ailettes", info: "De fines lames de métal : elles offrent une grande surface à l'air, qui emporte la chaleur.", image: "images/refroidissement/radiateur.svg", x: 300, y: 90, l: 60, h: 115 }
    ],
    quiz: [
      {
        question: "Que se passe-t-il si le processeur chauffe trop ?",
        choix: ["Il accélère", "Rien du tout", "Il ralentit pour se protéger, puis s'éteint"],
        bonne: 2,
        explication: "Le processeur surveille sa température et réduit sa vitesse avant d'atteindre un niveau dangereux."
      },
      {
        question: "Quel est le rôle du caloduc ?",
        choix: ["Transporter la chaleur du processeur jusqu'au radiateur", "Souffler de l'air", "Fournir du courant"],
        bonne: 0,
        explication: "Le ventilateur souffle l'air. Le caloduc, lui, déplace la chaleur de la plaque vers les ailettes."
      }
    ]
  },
  {
    id: "ram",
    nom: "Mémoire vive (RAM)",
    resume: "La mémoire de travail : très rapide, mais vidée quand on éteint.",
    role: "La mémoire vive garde sous la main les programmes ouverts et leurs données. Le processeur y lit et y écrit en permanence. Plus elle est grande, plus on peut ouvrir de choses en même temps sans ralentir.",
    analogie: "C'est le plan de travail de la cuisine : plus il est grand, plus on prépare de plats à la fois.",
    image: "images/ram/complet.svg",
    pieces: [
      { id: "circuit", nom: "Circuit imprimé", info: "La plaque qui porte les puces et les relie par de fines pistes de cuivre.", image: "images/ram/circuit.svg", x: 20, y: 100, l: 360, h: 100 },
      { id: "puces", nom: "Puces mémoire", info: "Elles stockent les données sous forme de minuscules charges électriques.", image: "images/ram/puces.svg", x: 40, y: 112, l: 320, h: 50 },
      { id: "contacts", nom: "Contacts dorés", info: "Ces lamelles s'enfoncent dans le connecteur de la carte mère.", image: "images/ram/contacts.svg", x: 20, y: 178, l: 360, h: 22 }
    ],
    quiz: [
      {
        question: "Que devient le contenu de la RAM quand on éteint l'ordinateur ?",
        choix: ["Il est conservé", "Il est effacé", "Il est copié sur l'écran"],
        bonne: 1,
        explication: "La RAM est une mémoire volatile : sans courant, elle se vide."
      },
      {
        question: "À quoi sert d'avoir plus de mémoire vive ?",
        choix: ["À garder plus de programmes ouverts en même temps", "À stocker plus de photos", "À avoir une image plus nette"],
        bonne: 0,
        explication: "Les photos se rangent sur le SSD. La RAM sert aux programmes en cours d'utilisation."
      }
    ]
  },
  {
    id: "ssd",
    nom: "Stockage (SSD)",
    resume: "La mémoire longue durée : elle garde les fichiers même éteinte.",
    role: "Le SSD conserve le système, les programmes et vos fichiers. Il n'a aucune pièce mobile : il est rapide, silencieux et résiste aux chocs.",
    analogie: "C'est la réserve de la cuisine : tout y reste rangé, même quand la cuisine est fermée.",
    image: "images/ssd/complet.svg",
    pieces: [
      { id: "circuit", nom: "Circuit imprimé", info: "Une plaquette étroite au format M.2, à peine plus grande qu'une tablette de chewing-gum.", image: "images/ssd/circuit.svg", x: 40, y: 110, l: 320, h: 80 },
      { id: "connecteur", nom: "Connecteur", info: "Ses contacts dorés se glissent dans le connecteur M.2 de la carte mère.", image: "images/ssd/connecteur.svg", x: 40, y: 112, l: 14, h: 76 },
      { id: "controleur", nom: "Contrôleur", info: "Le chef d'orchestre : il décide où ranger chaque donnée et sait la retrouver.", image: "images/ssd/controleur.svg", x: 90, y: 125, l: 50, h: 50 },
      { id: "flash", nom: "Puces de mémoire flash", info: "Elles gardent les données sans courant, pendant des années.", image: "images/ssd/flash.svg", x: 165, y: 120, l: 170, h: 60 }
    ],
    quiz: [
      {
        question: "Pourquoi un SSD est-il silencieux ?",
        choix: ["Il est très petit", "Il est éteint la plupart du temps", "Il n'a aucune pièce mobile"],
        bonne: 2,
        explication: "Il stocke les données dans des puces, sans disque qui tourne."
      },
      {
        question: "Quelle pièce du SSD décide où ranger les données ?",
        choix: ["Le contrôleur", "Le connecteur", "Le circuit imprimé"],
        bonne: 0,
        explication: "Le contrôleur range les données dans les puces de mémoire flash et les retrouve à la demande."
      }
    ]
  },
  {
    id: "batterie",
    nom: "Batterie",
    resume: "Le réservoir d'énergie : elle alimente l'ordinateur loin d'une prise.",
    role: "La batterie stocke de l'électricité sous forme chimique et la rend quand l'ordinateur est débranché. Une carte électronique la surveille en permanence pour qu'elle ne chauffe pas et ne se vide pas trop.",
    analogie: "C'est la bonbonne de gaz de la cuisine : elle permet de cuisiner sans être raccordé au réseau.",
    image: "images/batterie/complet.svg",
    pieces: [
      { id: "boitier", nom: "Boîtier", info: "L'enveloppe qui protège les cellules des chocs.", image: "images/batterie/boitier.svg", x: 20, y: 102, l: 360, h: 96 },
      { id: "cellules", nom: "Cellules", info: "Elles stockent l'énergie grâce à une réaction chimique réversible, à base de lithium.", image: "images/batterie/cellules.svg", x: 30, y: 112, l: 250, h: 76 },
      { id: "carte", nom: "Carte de gestion", info: "Elle surveille la charge et la température, et coupe le courant en cas de danger.", image: "images/batterie/carte.svg", x: 288, y: 112, l: 40, h: 76 },
      { id: "connecteur", nom: "Connecteur", info: "Il relie la batterie à la carte mère.", image: "images/batterie/connecteur.svg", x: 334, y: 124, l: 38, h: 52 }
    ],
    quiz: [
      {
        question: "Sous quelle forme la batterie stocke-t-elle l'énergie ?",
        choix: ["Sous forme de lumière", "Sous forme chimique", "Sous forme d'air comprimé"],
        bonne: 1,
        explication: "Des réactions chimiques réversibles permettent de la charger, puis de la décharger."
      },
      {
        question: "Que fait la carte de gestion ?",
        choix: ["Elle affiche le niveau à l'écran", "Elle recharge le téléphone", "Elle surveille la charge et la température"],
        bonne: 2,
        explication: "Elle protège les cellules : trop de charge ou de chaleur les abîmerait."
      }
    ]
  },
  {
    id: "ecran",
    nom: "Écran",
    resume: "La fenêtre : il affiche l'image calculée par l'ordinateur.",
    role: "Un écran LCD est un mille-feuille. Des LED éclairent par-derrière une dalle faite de millions de points, les pixels. Chaque pixel laisse passer plus ou moins de lumière rouge, verte et bleue pour composer l'image.",
    analogie: "C'est le passe-plat de la cuisine : c'est par là que le résultat arrive jusqu'à vous.",
    image: "images/ecran/complet.svg",
    pieces: [
      { id: "capot", nom: "Capot", info: "La coque arrière : elle protège l'écran et porte les charnières.", image: "images/ecran/capot.svg", x: 30, y: 20, l: 340, h: 250 },
      { id: "retroeclairage", nom: "Rétroéclairage", info: "Des LED éclairent la dalle par-derrière. Sans elles, l'image resterait noire.", image: "images/ecran/retroeclairage.svg", x: 44, y: 34, l: 312, h: 200 },
      { id: "dalle", nom: "Dalle", info: "Des millions de pixels. Chacun dose la lumière rouge, verte et bleue qu'il laisse passer.", image: "images/ecran/dalle.svg", x: 44, y: 34, l: 312, h: 200 },
      { id: "nappe", nom: "Nappe vidéo", info: "Ce câble plat apporte l'image depuis la carte mère en passant par la charnière.", image: "images/ecran/nappe.svg", x: 180, y: 225, l: 40, h: 60 },
      { id: "cadre", nom: "Cadre", info: "Il tient la dalle en place et loge la webcam.", image: "images/ecran/cadre.svg", x: 36, y: 26, l: 328, h: 238 }
    ],
    quiz: [
      {
        question: "De quoi est faite l'image sur l'écran ?",
        choix: ["De millions de pixels", "D'une seule grande ampoule", "De petits miroirs"],
        bonne: 0,
        explication: "Chaque pixel est un point minuscule dont la couleur change des dizaines de fois par seconde."
      },
      {
        question: "À quoi sert le rétroéclairage d'un écran LCD ?",
        choix: ["À chauffer l'écran", "À éclairer la dalle par-derrière", "À capter le Wi-Fi"],
        bonne: 1,
        explication: "La dalle ne produit pas de lumière : elle filtre celle des LED placées derrière elle."
      }
    ]
  },
  {
    id: "clavier",
    nom: "Clavier et pavé tactile",
    resume: "Les mains de l'utilisateur : ils transmettent les frappes et les gestes.",
    role: "Sous chaque touche, un contact se ferme quand on appuie. Le clavier signale alors à l'ordinateur quelle touche est enfoncée. Le pavé tactile, lui, repère la position du doigt pour déplacer le pointeur.",
    analogie: "C'est le carnet de commandes : c'est par là que les demandes arrivent en cuisine.",
    image: "images/clavier/complet.svg",
    pieces: [
      { id: "support", nom: "Dessus du châssis", info: "Il porte le clavier, le pavé tactile et le repose-poignets.", image: "images/clavier/support.svg", x: 10, y: 10, l: 380, h: 280 },
      { id: "membrane", nom: "Membrane", info: "Une feuille souple parcourue de pistes. Sous chaque touche, un contact se ferme à l'appui.", image: "images/clavier/membrane.svg", x: 25, y: 35, l: 350, h: 130 },
      { id: "touches", nom: "Touches", info: "Chaque touche repose sur un petit mécanisme qui la guide et la fait remonter.", image: "images/clavier/touches.svg", x: 25, y: 35, l: 350, h: 130 },
      { id: "pave", nom: "Pavé tactile", info: "Sa surface repère la position du doigt et les clics.", image: "images/clavier/pave.svg", x: 140, y: 185, l: 120, h: 75 }
    ],
    quiz: [
      {
        question: "Que se passe-t-il quand on appuie sur une touche ?",
        choix: ["La touche envoie de la lumière", "Le clavier se recharge", "Un contact se ferme sous la touche"],
        bonne: 2,
        explication: "Ce contact fermé indique au clavier quelle touche est enfoncée."
      },
      {
        question: "Comment le pavé tactile sait-il où est le doigt ?",
        choix: ["Une caméra filme la main", "Sa surface repère la position du doigt", "Il pèse le doigt"],
        bonne: 1,
        explication: "La surface détecte le contact de la peau et calcule sa position."
      }
    ]
  }
];

// L'ordinateur est un « grand composant » dont les pièces sont les composants ci-dessus.
// ordre: true impose de poser les pièces dans l'ordre de la liste, comme dans un vrai montage.
const ORDINATEUR = {
  id: "ordinateur",
  nom: "Ordinateur portable",
  fond: "images/ordinateur/chassis.svg",
  ordre: true,
  pieces: [
    { id: "carte-mere", nom: "Carte mère", info: "On la visse en premier au fond du châssis : tout le reste vient s'y brancher.", image: "images/carte-mere/complet.svg", x: 30, y: 30, l: 202, h: 141.5 },
    { id: "processeur", nom: "Processeur", info: "Il prend place sur son emplacement, au cœur de la carte mère.", image: "images/processeur/complet.svg", x: 161.2, y: 42.9, l: 57.9, h: 57.9 },
    { id: "refroidissement", nom: "Refroidissement", info: "Sa plaque se pose sur le processeur et le ventilateur souffle vers la sortie d'air.", image: "images/refroidissement/complet.svg", x: 160.9, y: 34.8, l: 214.5, h: 74.8 },
    { id: "ram", nom: "Mémoire vive (RAM)", info: "La barrette se clipse dans son connecteur.", image: "images/ram/complet.svg", x: 53.8, y: 115.5, l: 112, h: 31.1 },
    { id: "ssd", nom: "Stockage (SSD)", info: "Il se glisse dans le connecteur M.2 et se fixe avec une vis.", image: "images/ssd/complet.svg", x: 59.2, y: 55.3, l: 96, h: 24 },
    { id: "batterie", nom: "Batterie", info: "Elle occupe l'avant du châssis et se branche à la carte mère.", image: "images/batterie/complet.svg", x: 40, y: 188, l: 320, h: 85.3 },
    { id: "clavier", nom: "Clavier et pavé tactile", info: "Le dessus du châssis se referme sur les composants.", image: "images/clavier/complet.svg", x: 10, y: 10, l: 380, h: 280 },
    { id: "ecran", nom: "Écran", info: "L'écran se fixe aux charnières et se rabat : l'ordinateur est complet.", image: "images/ordinateur/capot-ferme.svg", x: 10, y: 10, l: 380, h: 280 }
  ]
};

// Retrouve un composant grâce à son identifiant. Renvoie null s'il n'existe pas.
function trouverComposant(id) {
  for (const composant of COMPOSANTS) {
    if (composant.id === id) {
      return composant;
    }
  }
  return null;
}

// Donne le rang d'un composant dans la liste : 0 pour le premier.
function rangComposant(id) {
  for (let rang = 0; rang < COMPOSANTS.length; rang++) {
    if (COMPOSANTS[rang].id === id) {
      return rang;
    }
  }
  return -1;
}
