// navigation.js : choisit la vue à afficher d'après la fin de l'adresse.
//   index.html              ou  index.html#accueil     -> l'accueil
//   index.html#ram          (l'identifiant d'un composant) -> la vue de ce composant
//   index.html#ordinateur                              -> le montage final

// Met à jour le compteur et la jauge du bandeau.
function mettreAJourEntete() {
  const termines = compterTermines();
  document.querySelector("#compteur").textContent = termines + " / " + COMPOSANTS.length;
  document.querySelector("#jauge").style.width = (termines / COMPOSANTS.length * 100) + "%";
}

function afficherVue() {
  const nom = window.location.hash.slice(1); // "#ram" devient "ram"
  const composant = trouverComposant(nom);

  for (const vue of document.querySelectorAll(".vue")) {
    vue.hidden = true;
  }

  if (composant !== null) {
    afficherComposant(composant);
    document.querySelector("#vue-composant").hidden = false;
  } else if (nom === "ordinateur") {
    afficherOrdinateur();
    document.querySelector("#vue-ordinateur").hidden = false;
  } else {
    afficherAccueil();
    document.querySelector("#vue-accueil").hidden = false;
  }

  mettreAJourEntete();
  window.scrollTo(0, 0);
}

// La vue change à chaque fois que la fin de l'adresse change, et une première fois au chargement.
window.addEventListener("hashchange", afficherVue);
afficherVue();
