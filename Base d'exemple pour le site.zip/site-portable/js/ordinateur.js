// ordinateur.js : la vue du montage final, débloquée quand tous les composants sont assemblés.

function afficherOrdinateur() {
  document.title = "Monter l'ordinateur | Dans mon portable";

  const zone = document.querySelector("#atelier-ordinateur");
  const manquants = document.querySelector("#manquants");
  const finale = document.querySelector("#finale");
  const restants = COMPOSANTS.length - compterTermines();

  finale.hidden = true;

  if (restants > 0) {
    // Il manque des composants : on affiche la liste de ceux qui restent à assembler.
    zone.hidden = true;
    manquants.hidden = false;
    const liste = document.querySelector("#liste-manquants");
    liste.innerHTML = "";
    for (const composant of COMPOSANTS) {
      if (!estTermine(composant.id)) {
        const ligne = document.createElement("li");
        ligne.innerHTML = `<a href="#${composant.id}">${composant.nom}</a>`;
        liste.appendChild(ligne);
      }
    }
  } else {
    // Tout est prêt : le même moteur sert au montage, avec l'ordinateur comme « grand composant ».
    manquants.hidden = true;
    zone.hidden = false;
    creerAtelier(zone, ORDINATEUR, function () {
      marquerTermine(ORDINATEUR.id);
      mettreAJourEntete();
      // On laisse le temps de voir l'écran se rabattre, puis on allume l'ordinateur.
      setTimeout(function () {
        zone.hidden = true;
        finale.hidden = false;
      }, 1400);
    });
  }
}

document.querySelector("#bouton-remonter").addEventListener("click", function () {
  afficherOrdinateur();
});
