// progression.js : retient les composants déjà assemblés, même après fermeture de la page.

const CLE_PROGRESSION = "portable-progression";

// Renvoie la liste des identifiants terminés, par exemple ["ram", "ssd"].
function lireProgression() {
  try {
    const texte = localStorage.getItem(CLE_PROGRESSION);
    if (texte === null) {
      return [];
    }
    return JSON.parse(texte);
  } catch (erreur) {
    return [];
  }
}

function estTermine(id) {
  return lireProgression().includes(id);
}

function marquerTermine(id) {
  const liste = lireProgression();
  if (!liste.includes(id)) {
    liste.push(id);
    try {
      localStorage.setItem(CLE_PROGRESSION, JSON.stringify(liste));
    } catch (erreur) {
      console.log("Sauvegarde impossible sur ce navigateur.");
    }
  }
}

function effacerProgression() {
  try {
    localStorage.removeItem(CLE_PROGRESSION);
  } catch (erreur) {
    console.log("Rien à effacer sur ce navigateur.");
  }
}

// Compte les composants terminés parmi la liste COMPOSANTS.
function compterTermines() {
  let total = 0;
  for (const composant of COMPOSANTS) {
    if (estTermine(composant.id)) {
      total = total + 1;
    }
  }
  return total;
}
